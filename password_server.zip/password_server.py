
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return "Password Server is Running!"

@app.route('/check_password', methods=['POST'])
def check_password():
    stored_password = "your_secret_password"  # Replace this with your password
    user_password = request.json.get("password")

    if user_password == stored_password:
        return jsonify({"message": "Password correct, access granted."}), 200
    else:
        return jsonify({"message": "Incorrect password."}), 403

if __name__ == '__main__':
    app.run(debug=True)
